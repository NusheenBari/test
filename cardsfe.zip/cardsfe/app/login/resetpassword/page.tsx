
import ForgotPass from "@/app/components/signin/ForgotPass"

const PasswordReset = () => {
  return (

    
    <ForgotPass/>
  )
}

export default PasswordReset
