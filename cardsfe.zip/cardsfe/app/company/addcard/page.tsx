'use client'

import NewCard from "@/app/components/dashboard/NewCard";
import Navbar from "@/app/components/Navbar";

export default function AddCard() {

    return(
        <>

                <Navbar/>
                <NewCard/>


           
        </>

    )
}