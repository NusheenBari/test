import CompanyUpdate from "../components/dashboard/CompanyUpdate";
import Navbar from "../components/Navbar";

export default function CompanyForm(){


    return(
        <>


                <Navbar/>
                <CompanyUpdate/>

            
        </>
    )
}