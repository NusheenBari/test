export default function Company() {
    return(
        <>
            <p>Company details form</p>
        </>
    )
}