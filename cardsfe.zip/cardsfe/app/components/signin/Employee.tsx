export default function Employee(){
    return(
        <>
            <p>Employee add card info</p>
        </>
    )
}