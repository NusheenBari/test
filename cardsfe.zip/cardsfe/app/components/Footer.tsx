export default function Footer(){
    return(
        <div className="text-center text-xs text-black-600 bg-slate-200 pt-5 pb-5 py-5">
            <p>

            Copyright 2023 © Cards Digify. All Rights Reserved.

            </p>
        </div>
    )
}